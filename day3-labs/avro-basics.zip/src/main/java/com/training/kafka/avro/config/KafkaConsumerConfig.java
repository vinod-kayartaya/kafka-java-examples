
package com.training.kafka.avro.config;

import java.util.Properties;

public class KafkaConsumerConfig {
    public static Properties create() {
        Properties p = new Properties();
        p.put("bootstrap.servers","localhost:9092");
        p.put("group.id","avro-demo-group");
        p.put("key.deserializer","org.apache.kafka.common.serialization.StringDeserializer");
        p.put("value.deserializer","org.apache.kafka.common.serialization.ByteArrayDeserializer");
        p.put("auto.offset.reset","earliest");
        return p;
    }
}
