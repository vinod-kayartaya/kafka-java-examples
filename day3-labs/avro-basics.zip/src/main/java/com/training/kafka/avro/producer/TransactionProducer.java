
package com.training.kafka.avro.producer;

import com.training.kafka.avro.config.KafkaProducerConfig;
import com.training.kafka.avro.util.KafkaUtil;
import org.apache.kafka.clients.producer.*;

public class TransactionProducer {
    public void send() {
        try(var producer = new KafkaProducer<String, byte[]>(KafkaProducerConfig.create())) {
            ProducerRecord<String, byte[]> record =
                new ProducerRecord<>(KafkaUtil.TOPIC,"TXN1001","Sample Avro Payload".getBytes());
            producer.send(record);
            producer.flush();
            System.out.println("Message sent");
        }
    }
}
