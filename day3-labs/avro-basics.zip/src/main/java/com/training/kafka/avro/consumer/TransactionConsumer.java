
package com.training.kafka.avro.consumer;

import com.training.kafka.avro.config.KafkaConsumerConfig;
import com.training.kafka.avro.util.KafkaUtil;
import org.apache.kafka.clients.consumer.*;

import java.time.Duration;

public class TransactionConsumer {
    public void consume() {
        try(var consumer = new KafkaConsumer<String, byte[]>(KafkaConsumerConfig.create())) {
            consumer.subscribe(java.util.List.of(KafkaUtil.TOPIC));
            while(true){
                var records = consumer.poll(Duration.ofSeconds(1));
                records.forEach(r -> System.out.println(new String(r.value())));
            }
        }
    }
}
