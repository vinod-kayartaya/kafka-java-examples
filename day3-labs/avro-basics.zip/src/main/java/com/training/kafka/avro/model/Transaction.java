
package com.training.kafka.avro.model;

public class Transaction {
    private String transactionId;
    private String customerId;
    private double amount;

    public Transaction(String transactionId,String customerId,double amount){
        this.transactionId=transactionId;
        this.customerId=customerId;
        this.amount=amount;
    }

    public String toString(){
        return transactionId + "," + customerId + "," + amount;
    }
}
