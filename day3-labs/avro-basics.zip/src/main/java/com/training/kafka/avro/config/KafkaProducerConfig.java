
package com.training.kafka.avro.config;

import java.util.Properties;

public class KafkaProducerConfig {
    public static Properties create() {
        Properties p = new Properties();
        p.put("bootstrap.servers","localhost:9092");
        p.put("key.serializer","org.apache.kafka.common.serialization.StringSerializer");
        p.put("value.serializer","org.apache.kafka.common.serialization.ByteArraySerializer");
        return p;
    }
}
